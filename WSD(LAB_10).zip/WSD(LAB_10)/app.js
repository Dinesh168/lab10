const express = require('express');
const mysql = require("mysql");
const app = express();
var bodyparser = require("body-parser");


app.use(bodyparser.json())
app.use(express.static('client'))
app.use(bodyparser.urlencoded({
    extended: true
}))

//create coonections

const db = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "Dini7777",
    database: "employee_db"
});

db.connect((err) => {
    if (err)
        throw err;
    console.log("Connected to database");
});

app.get("/createdb", (req, res) => {
    let sql = "CREATE DATABASE employee_db";
    db.query(sql, (err, result) => {
        if (err) throw err;
        console.log("result");
        res.send("Database Created")
    })
})

app.get("/table", (req, res) => {
    let sql = "CREATE TABLE Users(id int, Name VARCHAR(10), Model VARCHAR(10),Company VARCHAR(10), Discount int, Amount int)";
    db.query(sql, (err, result) => {
        if (err) throw err;
        console.log("result");
        res.send("TABLE Created");
    })
})

app.post("/insert", (req, res) => {

    let post = {
        id: `${req.body.id}`, Name: `${req.body.name}`, Model: `${req.body.model}`, Company: `${req.body.company}`, Discount: `${req.body.discount}`, Amount: `${req.body.amount}`
    };
    let sql = "INSERT INTO Users set ?";
    db.query(sql, post, (err, result) => {
        if (err) throw err;
        console.log("result");
    })
    return res.redirect("page2.html")
})



app.get("/get", (req, res) => {
    let sql = "SELECT * FROM Users";
    let query = db.query(sql, (err, result) => {
        if (err) throw err;
        res.setHeader('Content-Type', 'application/json')
        res.end(JSON.stringify(result))

    })
})


app.post("/update", (req, res) => {
    let sql = `Update Users set Name = '${req.body.name}' WHERE id = ${req.body.id}`;
    db.query(sql, (err, result) => {
        if (err) throw err;
        console.log(result);
        return res.redirect("page2.html")
    })
})

app.post("/search", (req, res) => {
    let sql = `SELECT * FROM Users WHERE id = ${req.body.id} `;
    let query = db.query(sql, (err, result) => {
        if (err) throw err;
        console.log(result);
        return res.redirect("page2.html")
    })
})


app.post("/delete", (req, res) => {
    let sql = `DELETE FROM Users WHERE id = ${req.body.id} `;
    db.query(sql, (err, result) => {
        if (err) throw err;
        console.log(result);
        return res.redirect("page2.html")
    })
})

app.get("/", (req, res) => {
    res.set({
        "ALLow-access-ALLow-Origin": '*'
    })
    return res.redirect('home.html')
}).listen(3000);
console.log("Server  is successfully runnnig on port 3000");
