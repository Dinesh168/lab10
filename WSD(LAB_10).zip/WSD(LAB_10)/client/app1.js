(function () {
    angular.module("myApp", ["ngRoute"])
        // Verification
        // .controller('myCtrl', function($scope) {
        //     $scope.xyz = "cdcd"
        // })

        .controller('homeController', function ($scope, $http) {
            $http.get('http://localhost:3000/get').then((response) => {
                $scope.datas = response.data
            })
        })


        .config(function ($routeProvider) {
            $routeProvider
                .when('/', {
                    templateUrl: 'Display.html',
                    controller: 'homeController'
                })
        })
        .config(function ($locationProvider) {
            $locationProvider.hashPrefix('')
        })
})();